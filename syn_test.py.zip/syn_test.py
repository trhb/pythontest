print("Type Test")
alpha=input()
if alpha==("test") or ("Test"):
    print("Test Successful")
else:
    print("Epic Fail")

input()
